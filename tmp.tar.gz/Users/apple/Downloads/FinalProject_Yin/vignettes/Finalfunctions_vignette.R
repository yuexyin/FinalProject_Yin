## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(FinalProjectYin)
library(dplyr)
library(knitr)
library(kableExtra)
library(flextable)
library(ggplot2)
library(ggpubr)

## -----------------------------------------------------------------------------
ephys <- read.csv("Ephys_Yin.csv", header = TRUE)

## -----------------------------------------------------------------------------
head(ephys1 <- ephysfilter(ephys))

## -----------------------------------------------------------------------------
Thresholdplot(ephys1, "Treatment", "Voltage.threshold.mV", "Voltage Threshold (mV)")

## -----------------------------------------------------------------------------
StatsTable(ephys1, "alcohol", "water", "Cell.ID", "Voltage.threshold.mV")
StatsTable(ephys1, "alcohol", "water", "Cell.ID", "Current.Threshold..pA.")

## -----------------------------------------------------------------------------
normaldisplot(ephys1, "alcohol", "Voltage.threshold.mV", "Voltage Threshold (mV)")

## -----------------------------------------------------------------------------
normalization(ephys1, "Voltage.threshold.mV", "alcohol")

## -----------------------------------------------------------------------------
threshttest("Voltage.threshold.mV", ephys1)
threshttest("Current.Threshold..pA.", ephys1)

